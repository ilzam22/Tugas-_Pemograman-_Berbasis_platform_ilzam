# Tugas Mandiri 2 — Memahami HTTP Status Code

## Pengujian Status Code

| Status Code | Arti | Hasil Pengujian | Kapan Digunakan |
|---:|---|---|---|
| 200 | OK | Server mengembalikan status 200 | Saat request berhasil diproses |
| 201 | Created | Server mengembalikan status 201 | Saat resource berhasil dibuat |
| 400 | Bad Request | Server mengembalikan status 400 | Saat request dari client tidak valid |
| 401 | Unauthorized | Server mengembalikan status 401 | Saat autentikasi diperlukan atau tidak valid |
| 403 | Forbidden | Server mengembalikan status 403 | Saat akses ditolak karena tidak memiliki izin |
| 404 | Not Found | Server mengembalikan status 404 | Saat route atau resource tidak ditemukan |
| 500 | Internal Server Error | Server mengembalikan status 500 | Saat terjadi error internal pada server |

## Endpoint Pengujian

- GET https://httpbin.org/status/200
- GET https://httpbin.org/status/201
- GET https://httpbin.org/status/400
- GET https://httpbin.org/status/401
- GET https://httpbin.org/status/403
- GET https://httpbin.org/status/404
- GET https://httpbin.org/status/500

## Jawaban Pertanyaan

### 1. Perbedaan 400 dan 404

400 Bad Request menunjukkan bahwa request dari client tidak valid atau tidak dapat diproses karena format atau isi request bermasalah. Sedangkan 404 Not Found menunjukkan bahwa route atau resource yang diminta tidak ditemukan.

### 2. Perbedaan 401 dan 403

401 Unauthorized digunakan ketika request membutuhkan autentikasi atau kredensial autentikasi tidak valid. 403 Forbidden menunjukkan bahwa server memahami request tetapi client tidak memiliki izin untuk mengakses resource.

### 3. Mengapa 500 menunjukkan masalah pada sisi server?

500 Internal Server Error menunjukkan bahwa server mengalami masalah internal sehingga request tidak dapat diproses sebagaimana mestinya.

### 4. Apakah semua error HTTP berarti server mengalami kerusakan?

Tidak. Error 400, 401, 403, dan 404 umumnya berkaitan dengan request, autentikasi, izin, atau resource yang diminta client. Status 500 menunjukkan masalah internal pada server.

## Kesimpulan

Pengujian status code menunjukkan bahwa setiap status HTTP memiliki arti yang berbeda. Status 2xx menunjukkan keberhasilan, sedangkan status 4xx umumnya berhubungan dengan request atau akses dari client dan status 5xx menunjukkan masalah internal pada server.