# Tugas Mandiri 1 — Mengenal HTTP Method dan Endpoint

## Tujuan

Pengujian ini dilakukan untuk memahami hubungan antara HTTP method,
endpoint, parameter, request, dan response menggunakan layanan HTTPBin.

## Hasil Pengujian

| No | Method | Endpoint | Data yang Dikirim | Status | Hasil |
|---:|---|---|---|---:|---|
| 1 | GET | `/get` | Query parameter `nama=Umar&kelas=TI` | 200 | Berhasil, server mengembalikan informasi request dan query parameter |
| 2 | POST | `/post` | JSON `{ "nama": "Umar", "kelas": "Informatika" }` | 200 | Berhasil, server mengembalikan informasi request dan body JSON |
| 3 | PUT | `/put` | JSON `{ "nama": "Umar", "kelas": "Informatika" }` | 200 | Berhasil, server mengembalikan informasi request PUT dan data yang dikirim |
| 4 | PATCH | `/patch` | JSON `{ "nama": "Umar", "kelas": "Informatika" }` | 200 | Berhasil, server mengembalikan informasi request PATCH dan data yang dikirim |
| 5 | DELETE | `/delete` | - | 200 | Berhasil, server mengembalikan informasi request DELETE |

## 1. GET /get

### Method
GET

### URL Lengkap

`https://httpbin.org/get?nama=Umar&kelas=TI`

### Tujuan

Menguji request GET dan penggunaan query parameter.

### Data yang Dikirim

Query parameter:

- `nama=Umar`
- `kelas=TI`

### Status Code

200 OK

### Response Body

Tempel response asli dari Postman di sini.

### Informasi yang Dikembalikan Server

HTTPBin mengembalikan informasi request yang diterima server, termasuk
query parameter, header, origin, dan URL request.

## 2. POST /post

### Method
POST

### URL Lengkap

`https://httpbin.org/post`

### Tujuan

Menguji request POST dengan data JSON pada request body.

### Data yang Dikirim

```json
{
  "nama": "Umar",
  "kelas": "Informatika"
}