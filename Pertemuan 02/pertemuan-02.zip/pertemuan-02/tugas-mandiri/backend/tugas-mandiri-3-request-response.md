# Tugas Mandiri 3 — Memahami Request dan Response

## Pengujian GET /get

Endpoint:

`https://httpbin.org/get?nama=Umar&kelas=TI`

Method:

GET

Query parameter:

- `nama=Umar`
- `kelas=TI`

Status:

200 OK

### Informasi Response

HTTPBin mengembalikan informasi request yang diterima server. Pada bagian `args`, server menampilkan kembali query parameter yang dikirim, yaitu `nama` dan `kelas`. Response juga berisi informasi seperti header, origin, dan URL request.

### Contoh response

```json
{
  "args": {
    "kelas": "TI",
    "nama": "Umar"
  }
}