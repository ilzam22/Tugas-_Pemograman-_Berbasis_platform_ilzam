# Tugas Mandiri 4 — Pengujian API dengan Postman dan curl

## A. Pengujian dengan Postman

### 1. GET https://httpbin.org/get

Method: GET

URL:

`https://httpbin.org/get`

Status: 200 OK

Hasil:

Request GET berhasil. Server mengembalikan informasi request
yang diterima, termasuk header, origin, dan URL request.

Response lengkap ditunjukkan pada screenshot Postman GET.

### 2. POST https://httpbin.org/post

Method: POST

URL:

`https://httpbin.org/post`

Body:

```json
{
  "nama": "Umar",
  "kelas": "Informatika"
}