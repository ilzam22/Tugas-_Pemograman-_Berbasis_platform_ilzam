# Tugas Mandiri 5 — Membandingkan SQL Mentah dan ORM

## 1. Operasi yang Dipilih

Saya memilih operasi mengambil satu data jadwal berdasarkan ID.

Tabel yang digunakan adalah `jadwal`.

ID yang dicari adalah `1`.
## 2. SQL Mentah

Query SQL:

```sql
SELECT *
FROM jadwal
WHERE id = ?;
Contoh jika menggunakan Node.js dan mysql2:

```js
const [rows] = await connection.execute(
  'SELECT * FROM jadwal WHERE id = ?',
  [1]
);

console.log(rows);

## 3. Prisma ORM

Operasi yang sama menggunakan Prisma:

```js
const jadwal = await prisma.jadwal.findUnique({
  where: {
    id: 1,
  },
});

console.log(jadwal);

Ini juga berarti:

> cari satu data jadwal dengan ID 1.

---

# LANGKAH 7 — Bandingkan keduanya

Tambahkan:

```md
## 4. Perbandingan

| Aspek | SQL Mentah | Prisma ORM |
|---|---|---|
| Cara menulis | Menulis SQL langsung | Menggunakan method Prisma |
| Kontrol query | Lebih tinggi | Lebih diabstraksikan |
| Kemudahan | Perlu memahami SQL | Lebih mudah digunakan |
| Cocok untuk | Query khusus/kompleks | CRUD dan aplikasi |

## 5. Jawaban Pertanyaan

### 1. Apa perbedaan SQL mentah dan ORM?

SQL mentah adalah cara mengakses database dengan menulis query SQL
secara langsung. ORM adalah cara mengakses database melalui object dan
method dari bahasa pemrograman sehingga programmer tidak perlu selalu
menulis query SQL secara langsung.

### 2. Apa kelebihan SQL mentah?

SQL mentah memberikan kontrol yang lebih besar terhadap query database
dan cocok digunakan untuk query yang kompleks atau membutuhkan
optimasi khusus.

### 3. Apa kelebihan ORM?

ORM memudahkan programmer dalam mengakses database menggunakan object
dan method. ORM juga dapat mengurangi penulisan query SQL secara
berulang dan membuat kode lebih mudah dipelihara.

### 4. Apa risiko SQL injection?

SQL injection adalah serangan ketika input dari pengguna dimasukkan
langsung ke dalam query SQL sehingga input tersebut dapat memanipulasi
query dan menjalankan perintah yang tidak seharusnya.

Contoh yang tidak aman:

```js
const id = userInput;

const sql = `SELECT * FROM jadwal WHERE id = ${id}`;

### 5. Mengapa penggunaan parameter query dapat mengurangi risiko SQL injection?

Parameterized query memisahkan nilai input dari struktur SQL. Nilai yang
diberikan pengguna diperlakukan sebagai data, bukan sebagai bagian dari
sintaks SQL.

Contoh:

```js
const [rows] = await connection.execute(
  'SELECT * FROM jadwal WHERE id = ?',
  [id]
);

### 6. Bagaimana ORM membantu programmer dalam mengakses database?

ORM membantu programmer dengan menyediakan abstraction layer untuk
mengakses database menggunakan object dan method. Programmer dapat
melakukan operasi seperti mencari, menambah, mengubah, dan menghapus
data dengan cara yang lebih sederhana dan konsisten.

## 6. Kesimpulan

SQL mentah memberikan kontrol yang lebih besar terhadap query database,
sedangkan ORM seperti Prisma memberikan cara yang lebih sederhana untuk
mengakses database melalui object dan method. SQL mentah cocok untuk
query yang sangat khusus atau kompleks, sedangkan ORM cocok untuk
pengembangan aplikasi dan operasi CRUD. Parameterized query penting
untuk membantu mengurangi risiko SQL injection.